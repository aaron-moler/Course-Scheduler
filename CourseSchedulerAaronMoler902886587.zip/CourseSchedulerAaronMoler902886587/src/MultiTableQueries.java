/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import java.sql.Timestamp;
import java.util.Map;
import java.util.HashMap;

/**
 *
 * @author ajm
 */
public class MultiTableQueries {
    private static Connection connection;
    private static PreparedStatement getAllClassDescriptions;
    private static ResultSet resultSet;
    private static PreparedStatement getScheduledStudentsByClass;
    private static PreparedStatement getWaitlistedStudentsByClass;
    
    //for a given semester, return a list of class descriptions
    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester){
        connection = DBConnection.getConnection();
        ArrayList<ClassDescription> classDescriptions = new ArrayList<ClassDescription>();
        
        try{
            getAllClassDescriptions = connection.prepareStatement("SELECT coursecode, description, seats FROM app.class WHERE semester = ?");
            getAllClassDescriptions.setString(1,semester);
            resultSet = getAllClassDescriptions.executeQuery();
            
            while(resultSet.next()){
                String courseCode = resultSet.getString("coursecode");
                String description = resultSet.getString("description");
                int seats = resultSet.getInt("seats");
                
                ClassDescription classDescription = new ClassDescription(courseCode, description, seats);
                classDescriptions.add(classDescription);
            }
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return classDescriptions;
    }
    //make a list of students that are actually in the class
    public static ArrayList<StudentEntry> getScheduledStudentsByClass(String semester, String courseCode){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();

        try {
            getScheduledStudentsByClass = connection.prepareStatement(
                    "SELECT studentid FROM app.schedule WHERE semester = ? AND coursecode = ? AND status = 'Scheduled'");
            getScheduledStudentsByClass.setString(1, semester);
            getScheduledStudentsByClass.setString(2, courseCode);
            resultSet = getScheduledStudentsByClass.executeQuery();

            while (resultSet.next()) {
                String studentID = resultSet.getString("studentid");
                StudentEntry student = StudentQueries.getStudent(studentID);

                if (student != null) {
                    students.add(student);
                }
            }

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return students;
    }
    
    //make a SORTED list of waitlisted students
    public static ArrayList<StudentEntry> getWaitlistedStudentsByClass(String semester, String courseCode){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();

        try {
            getWaitlistedStudentsByClass = connection.prepareStatement(
                    "SELECT studentid FROM app.schedule WHERE semester = ? AND coursecode = ? AND status = 'Waitlisted'");
            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, courseCode);
            resultSet = getWaitlistedStudentsByClass.executeQuery();

            // map students with their timestamps for the comparator
            Map<StudentEntry, Timestamp> studentTimestampMap = new HashMap<>();

            while (resultSet.next()) {
                String studentID = resultSet.getString("studentid");
                StudentEntry student = StudentQueries.getStudent(studentID);

                if (student != null) {
                    PreparedStatement getTimestampStmt = connection.prepareStatement(
                            "SELECT timestamp FROM app.schedule WHERE studentid = ? AND semester = ? AND coursecode = ?");
                    getTimestampStmt.setString(1, studentID);
                    getTimestampStmt.setString(2, semester);
                    getTimestampStmt.setString(3, courseCode);
                    ResultSet timestampResultSet = getTimestampStmt.executeQuery();

                    if (timestampResultSet.next()) {
                        Timestamp timestamp = timestampResultSet.getTimestamp("timestamp");
                        studentTimestampMap.put(student, timestamp);
                    }
                }
            }

            // Sort students based on timestamps
            ArrayList<StudentEntry> sortedStudents = new ArrayList<>(studentTimestampMap.keySet());
            Collections.sort(sortedStudents, new Comparator<StudentEntry>() {
                @Override
                public int compare(StudentEntry s1, StudentEntry s2) {
                    Timestamp timestamp1 = studentTimestampMap.get(s1);
                    Timestamp timestamp2 = studentTimestampMap.get(s2);
                    return timestamp1.compareTo(timestamp2);
                }
            });
            
            students = sortedStudents;

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return students;
    }
}
