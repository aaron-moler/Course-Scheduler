/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author ajm
 */
public class StudentQueries {
   
    private static Connection connection;
    private static PreparedStatement addStudent;
    private static PreparedStatement getAllStudents;
    private static ResultSet resultSet;
    private static PreparedStatement getID;
    private static PreparedStatement getStudent;
    private static PreparedStatement dropStudent;
    
    //add a student to the database
    public static void addStudent(StudentEntry student)
    {
        connection = DBConnection.getConnection();
        String studentID = student.getStudentID();
        String firstName = student.getFirstName();
        String lastName = student.getLastName();
        
        try
        {
            addStudent = connection.prepareStatement("insert into app.student (studentid,firstname,lastname) values (?,?,?)");
            addStudent.setString(1, studentID);
            addStudent.setString(2, firstName);
            addStudent.setString(3, lastName);
            addStudent.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    //get a list of all students
    public static ArrayList<StudentEntry> getAllStudents()
    {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();
        try
        {
            getAllStudents = connection.prepareStatement("SELECT studentid,firstname,lastname FROM app.student ORDER BY studentid");
            resultSet = getAllStudents.executeQuery();
            
            while(resultSet.next())
            {
                String studentID = resultSet.getString("studentid");
                String firstName = resultSet.getString("firstname");
                String lastName = resultSet.getString("lastname");
                
                StudentEntry student = new StudentEntry(studentID, firstName, lastName);
                students.add(student);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return students;
        
    }
    //get strudent ID from their name
    public static String getStudentID(String firstName, String lastName){
        connection = DBConnection.getConnection();
        String studentID = null;
        try
        {
            getID = connection.prepareStatement("Select studentid FROM app.student WHERE firstname = ? AND lastname = ?");
            getID.setString(1, firstName);
            getID.setString(2, lastName);
            resultSet = getID.executeQuery();
            
            if (resultSet.next()) {
            studentID = resultSet.getString("studentid");
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        return studentID;
    }
    
    public static StudentEntry getStudent(String studentID){
        connection = DBConnection.getConnection();
        StudentEntry student = null;

        try {
            getStudent = connection.prepareStatement("SELECT firstname, lastname FROM app.student WHERE studentid = ?");
            getStudent.setString(1, studentID);
            resultSet = getStudent.executeQuery();

            if (resultSet.next()) {
                String firstName = resultSet.getString("firstname");
                String lastName = resultSet.getString("lastname");

                student = new StudentEntry(studentID, firstName, lastName);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return student;
    }
    
    public static void dropStudent(String studentID){
        connection = DBConnection.getConnection();
        
        try {
            dropStudent = connection.prepareStatement("DELETE FROM app.student WHERE studentid = ?");
            dropStudent.setString(1, studentID);
            dropStudent.executeUpdate();
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
}
