/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Timestamp;
/**
 *
 * @author ajm
 */
public class ScheduleQueries {
    
    private static Connection connection;
    private static PreparedStatement addScheduleEntry;
    private static PreparedStatement getScheduledByStudent;
    private static PreparedStatement getScheduledStudentCount;
    private static PreparedStatement checkID;
    private static ResultSet resultSet;
    private static PreparedStatement getWaitlistedStudentsByClass;
    private static PreparedStatement dropStudentScheduleByCourse;
    private static PreparedStatement dropScheduleByCourse;
    private static PreparedStatement updateScheduleEntry;
    private static PreparedStatement getScheduleEntry;
    
    //add a student's schedule to the database
    public static void addScheduleEntry(ScheduleEntry schedule)
    {
        connection = DBConnection.getConnection();
        String semester = schedule.getSemester();
        String courseCode = schedule.getCourseCode();
        String studentID = schedule.getStudentID();
        String status = schedule.getStatus();
        Timestamp timestamp = schedule.getTimestamp();
        
        try
        {
            addScheduleEntry = connection.prepareStatement("insert into app.schedule (semester,coursecode,studentid,status,timestamp) values (?,?,?,?,?)");
            addScheduleEntry.setString(1, semester);
            addScheduleEntry.setString(2, courseCode);
            addScheduleEntry.setString(3, studentID);
            addScheduleEntry.setString(4, status);
            addScheduleEntry.setTimestamp(5, timestamp);
            addScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    //get a list of each student's schedules given their IDs and the given semester
    public static ArrayList<ScheduleEntry> getScheduledByStudent(String semester, String studentID)
    {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> schedules = new ArrayList<ScheduleEntry>();
        try
        {
            getScheduledByStudent = connection.prepareStatement("SELECT coursecode,status,timestamp FROM app.schedule WHERE semester = ? AND studentid = ?");
            getScheduledByStudent.setString(1,semester);
            getScheduledByStudent.setString(2, studentID);
            resultSet = getScheduledByStudent.executeQuery();
            
            while(resultSet.next())
            {
                String courseCode = resultSet.getString(1);
                String status = resultSet.getString(2);
                Timestamp timestamp = resultSet.getTimestamp(3);
                ScheduleEntry schedule = new ScheduleEntry(semester,courseCode,studentID, status, timestamp);
                schedules.add(schedule);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return schedules;   
    }
    //get number of students enrolled in a course
    public static int getScheduledStudentCount(String semester, String courseCode){
       connection = DBConnection.getConnection();
       int count = 0;
       try
        {
            getScheduledStudentCount = connection.prepareStatement("SELECT studentid FROM app.schedule WHERE semester = ? AND coursecode = ?");
            getScheduledStudentCount.setString(1,semester);
            getScheduledStudentCount.setString(2, courseCode);
            resultSet = getScheduledStudentCount.executeQuery();
            
            while(resultSet.next())
            {
                count++;
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
       
       
       return count;
   }
   //verify whether or not a student has already been enrolled in a class
   public static boolean checkID(String semester, String studentID, String courseCode){
       connection = DBConnection.getConnection();
       boolean check = false;
       
       try
        {
            checkID = connection.prepareStatement("SELECT COUNT(*) FROM app.schedule WHERE semester = ? and studentID = ? and courseCode = ?");
            checkID.setString(1, semester);
            checkID.setString(2, studentID);
            checkID.setString(3, courseCode);
            resultSet = checkID.executeQuery();
            if (resultSet.next()) {
            check = resultSet.getInt(1) > 0;
            }
            
        }
        catch(SQLException sqlException)
        {
            System.out.println("here");
            sqlException.printStackTrace();
        }
       
       return check;
   }
   //given a course and semester, make a list of the waitlisted students
   public static ArrayList<ScheduleEntry> getWaitlistedStudentsByClass(String semester, String courseCode){
       connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> waitlistedStudents = new ArrayList<>();

        try {
            getWaitlistedStudentsByClass = connection.prepareStatement("SELECT studentid, status, timestamp FROM app.schedule "
                    + "WHERE semester = ? AND coursecode = ? AND status = 'Waitlisted'");

            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, courseCode);
            resultSet = getWaitlistedStudentsByClass.executeQuery();

            while (resultSet.next()) {
                String studentID = resultSet.getString("studentid");
                String status = resultSet.getString("status");
                Timestamp timestamp = resultSet.getTimestamp("timestamp");
                ScheduleEntry scheduleEntry = new ScheduleEntry(semester, courseCode, studentID, status, timestamp);
                waitlistedStudents.add(scheduleEntry);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return waitlistedStudents;
   }
   //remove rows in schedule database with a given semester, id, and course
    public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode){
       connection = DBConnection.getConnection();

        try {
            dropStudentScheduleByCourse = connection.prepareStatement(
                "DELETE FROM app.schedule WHERE semester = ? AND studentid = ? AND coursecode = ?"
            );

            dropStudentScheduleByCourse.setString(1, semester);
            dropStudentScheduleByCourse.setString(2, studentID);
            dropStudentScheduleByCourse.setString(3, courseCode);
            dropStudentScheduleByCourse.executeUpdate();

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    //remove the course and everyone's enrollment in it from the database in the given semester
    public static void dropScheduleByCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();

        try {
            dropScheduleByCourse = connection.prepareStatement("DELETE FROM app.schedule WHERE semester = ? AND coursecode = ?");
            dropScheduleByCourse.setString(1, semester);
            dropScheduleByCourse.setString(2, courseCode);
            dropScheduleByCourse.executeUpdate();

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    
    //make a waitlisted enrolled in a course
    public static void updateScheduleEntry(ScheduleEntry entry){
        connection = DBConnection.getConnection();
        
        try {
            updateScheduleEntry = connection.prepareStatement(
                    "UPDATE app.schedule SET status = ? WHERE semester = ? AND coursecode = ? AND studentid = ?");

            updateScheduleEntry.setString(1, "Scheduled"); 
            updateScheduleEntry.setString(2, entry.getSemester());
            updateScheduleEntry.setString(3, entry.getCourseCode()); 
            updateScheduleEntry.setString(4, entry.getStudentID());
            updateScheduleEntry.executeUpdate();

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    // return a student's schedule given the course, semester, and ID
    // this is used for taking students off the waitlist
    public static ScheduleEntry getScheduleEntry(String semester, String courseCode, String studentID){
        connection = DBConnection.getConnection();
        ScheduleEntry scheduleEntry = null;
        try {
            getScheduleEntry = connection.prepareStatement(
                "SELECT * FROM app.schedule WHERE semester = ? AND coursecode = ? AND studentid = ?");
            getScheduleEntry.setString(1, semester);
            getScheduleEntry.setString(2, courseCode);
            getScheduleEntry.setString(3, studentID);
            ResultSet resultSet = getScheduleEntry.executeQuery();

            if (resultSet.next()) {
                String status = resultSet.getString("status");
                Timestamp timestamp = resultSet.getTimestamp("timestamp");

                scheduleEntry = new ScheduleEntry(semester, courseCode, studentID, status, timestamp);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return scheduleEntry;
    }
}
